<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../frontend/login.html");
    exit();
}

echo "Welcome, " . $_SESSION['user']['name'];
?>

<a href="logout.php">Logout</a>
