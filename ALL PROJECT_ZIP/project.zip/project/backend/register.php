<?php
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        // echo "Registration successful";
        echo '
        <script>
            alert("registration sucessfull");
            window.location = "../frontend/login.html";
            </script>
        ';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!-- echo '
        <script>
            alert("registration sucessfull");
            window.location = "#";
            </script>
        '; -->
