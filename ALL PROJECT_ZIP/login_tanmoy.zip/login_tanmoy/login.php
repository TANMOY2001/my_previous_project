<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to MySQL
    $conn = new mysqli("localhost", "root", "", "user");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);

    }

    // Get form data
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Retrieve user from database
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            echo '
    <script>
        alert("Login successful!!");
        window.location = "../";
    </script>
    ';
        } else {
            echo "Invalid username or password";
            echo '
    <script>
        alert("Invalid username or password!!");
        window.location = "../";
    </script>
    ';
        }
    } else {
        echo "Invalid username or password";
    }

    // Close connection
    $conn->close();
}
?>

