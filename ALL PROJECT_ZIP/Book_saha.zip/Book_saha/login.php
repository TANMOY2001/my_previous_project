<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$database = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeData($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars($data));
}

// Login functionality
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $usernameOrEmail = sanitizeData($_POST["usernameOrEmail"]);
    $password = sanitizeData($_POST["password"]);

    // Validate input (You can implement your own validation logic here)

    // Check if user exists in database
    $sql = "SELECT * FROM users WHERE (username = '$usernameOrEmail' OR email = '$usernameOrEmail')";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Password is correct, redirect to dashboard or homepage
            header("Location: home.html");
            exit();
        } else {
            // Password is incorrect, display error message or redirect to login page with error
            header("Location: login.php?error=password_incorrect");
            exit();
        }
    } else {
        // User not found, display error message or redirect to login page with error
        header("Location: login.php?error=user_not_found");
        exit();
    }
}

// Close connection
$conn->close();
?>
