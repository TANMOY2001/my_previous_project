<?php
// delete_from_cart.php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$item_id = $data['item_id'];

$stmt = $pdo->prepare("DELETE FROM cart_items WHERE user_id = ? AND item_id = ?");
$stmt->execute([$user_id, $item_id]);

echo json_encode(['success' => true]);
?>
