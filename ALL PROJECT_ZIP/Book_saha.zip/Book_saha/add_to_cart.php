<?php
// add_to_cart.php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$item_id = $data['item_id'];
$item_name = $data['item_name'];
$item_price = $data['item_price'];
$item_image = $data['item_image'];
$quantity = $data['quantity'];

$stmt = $pdo->prepare("SELECT * FROM cart_items WHERE user_id = ? AND item_id = ?");
$stmt->execute([$user_id, $item_id]);
$existingItem = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existingItem) {
    $stmt = $pdo->prepare("UPDATE cart_items SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?");
    $stmt->execute([$quantity, $user_id, $item_id]);
} else {
    $stmt = $pdo->prepare("INSERT INTO cart_items (user_id, item_id, item_name, item_price, item_image, quantity) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $item_id, $item_name, $item_price, $item_image, $quantity]);
}

echo json_encode(['success' => true]);
?>
