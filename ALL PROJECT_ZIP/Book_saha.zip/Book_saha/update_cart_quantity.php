<?php
require_once 'db.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $user_id = $_SESSION['user_id'];
    $item_id = $data->item_id;
    $quantity = $data->quantity;

    $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE user_id = ? AND item_id = ?");
    if ($stmt->execute([$quantity, $user_id, $item_id])) {
        echo json_encode(['success' => true, 'message' => 'Cart item quantity updated!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error updating cart item quantity!']);
    }
}
?>
