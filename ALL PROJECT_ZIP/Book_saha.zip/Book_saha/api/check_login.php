<?php
session_start();

$response = [
    "logged_in" => isset($_SESSION["logged_in"]) && $_SESSION["logged_in"]
];

echo json_encode($response);
?>
