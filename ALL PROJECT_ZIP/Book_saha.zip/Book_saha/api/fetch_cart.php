<?php
session_start();

if (!isset($_SESSION["logged_in"]) || !$_SESSION["logged_in"]) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "User not logged in"]);
    exit;
}

// Fetch the cart items for the logged-in user from the database
// For demonstration, we're returning a static list of cart items
$cartItems = [
    [
        "item_id" => "1",
        "item_name" => "Book 1",
        "item_price" => 100,
        "item_image" => "images/book1.jpg",
        "quantity" => 2
    ],
    [
        "item_id" => "2",
        "item_name" => "Book 2",
        "item_price" => 150,
        "item_image" => "images/book2.jpg",
        "quantity" => 1
    ]
];

$response = [
    "success" => true,
    "cart_items" => $cartItems
];

echo json_encode($response);
?>
