<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$database = "user";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeData($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars($data));
}

// Registration functionality
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register"])) {
    $fullName = sanitizeData($_POST["full_name"]);
    $email = sanitizeData($_POST["email"]);
    $password = sanitizeData($_POST["password"]);
    $confirmPassword = sanitizeData($_POST["confirmPassword"]);

    // Validate input (You can implement your own validation logic here)

    // Check if email already exists in database
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Email already registered, display error message or redirect to registration page with error
        header("Location: register.html?error=email_exists");
        exit();
    } else {
        // Insert user into database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password
        $sql = "INSERT INTO `users`(`id`, `full_name`, `email`, `password`, `created_at`) VALUES ('[value-1]','$fullName','$email','$password','[value-5]')";
        if ($conn->query($sql) === TRUE) {
            // Registration successful, redirect to login page or homepage
            header("Location: login.html?success=registration_successful");
            exit();
        } else {
            // Registration failed, display error message or redirect to registration page with error
            header("Location: register.html?error=registration_failed");
            exit();
        }
    }
}

// Close connection
$conn->close();
?>
