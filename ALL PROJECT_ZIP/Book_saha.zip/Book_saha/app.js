document.addEventListener("DOMContentLoaded", function () {
    let cartItems = [];

    const bookItems = document.querySelectorAll(".book-item");
    const cartIcon = document.querySelector(".icon-cart");
    const cartTab = document.querySelector(".cartTab");
    const closeBtn = document.querySelector(".bttn .close");
    const checkoutBtn = document.querySelector(".bttn .checkout");
    const cartList = document.querySelector(".ListCart");
    const totalBill = document.querySelector("#total-price");
    const loginModal = document.getElementById("loginModal");
    const loginForm = document.getElementById("loginForm");
    const loginBtn = document.getElementById("loginBtn");
    const logoutBtn = document.getElementById("logoutBtn");

    checkLoginStatus();

    closeBtn.addEventListener("click", () => {
        cartTab.style.display = "none";
    });

    cartIcon.addEventListener("click", () => {
        if (isLoggedIn()) {
            renderCart();
            cartTab.style.display = "block";
        } else {
            openLoginModal();
        }
    });

    bookItems.forEach(item => {
        const addButton = item.querySelector(".addcart");
        addButton.addEventListener("click", () => {
            const itemId = item.querySelector("img").id;
            const itemName = item.querySelector("h5").textContent;
            const itemPrice = parseFloat(item.querySelector(".price").textContent.replace('₹', ''));
            const itemImageSrc = item.querySelector("img").src;

            if (isLoggedIn()) {
                addToCart(itemId, itemName, itemPrice, itemImageSrc);
            } else {
                openLoginModal();
            }
        });
    });

    function addToCart(id, name, price, imageSrc) {
        const existingItem = cartItems.find(item => item.item_id === id);
        if (existingItem) {
            existingItem.quantity++;
        } else {
            cartItems.push({
                item_id: id,
                item_name: name,
                item_price: price,
                item_image: imageSrc,
                quantity: 1
            });
        }

        updateCartCountAndTotalBill();
    }

    function updateCartCountAndTotalBill() {
        const totalItems = cartItems.reduce((acc, item) => acc + item.quantity, 0);
        const totalPrice = cartItems.reduce((acc, item) => acc + (item.quantity * item.item_price), 0);

        document.querySelector(".icon-cart span").textContent = totalItems;
        totalBill.textContent = "Total: ₹" + totalPrice.toFixed(2);
    }

    function renderCart() {
        cartList.innerHTML = "";
        cartItems.forEach(item => {
            const cartItem = document.createElement("div");
            cartItem.classList.add("item");

            cartItem.innerHTML = `
                <div class="addcart">
                    <h3>${item.item_name}</h3>
                    <img src="${item.item_image}" alt="${item.item_name}" class="cart-image">
                    <h3 class="price">₹${item.item_price.toFixed(2)}</h3>
                    <div class="quantity">
                        <span class="minus" data-id="${item.item_id}">-</span>
                        <span>${item.quantity}</span>
                        <span class="plus" data-id="${item.item_id}">+</span>
                    </div>
                    <button class="delete" data-id="${item.item_id}">Delete</button>
                </div>
            `;

            const deleteBtn = cartItem.querySelector(".delete");
            deleteBtn.addEventListener("click", () => {
                deleteCartItem(item.item_id);
            });

            cartList.appendChild(cartItem);
        });

        const minusBtns = document.querySelectorAll(".quantity .minus");
        const plusBtns = document.querySelectorAll(".quantity .plus");

        minusBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                const itemId = btn.getAttribute("data-id");
                updateCartQuantity(itemId, -1);
            });
        });

        plusBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                const itemId = btn.getAttribute("data-id");
                updateCartQuantity(itemId, 1);
            });
        });
    }

    function deleteCartItem(itemId) {
        cartItems = cartItems.filter(item => item.item_id !== itemId);
        renderCart();
        updateCartCountAndTotalBill();
    }

    function updateCartQuantity(itemId, change) {
        const item = cartItems.find(item => item.item_id === itemId);
        if (item) {
            const newQuantity = item.quantity + change;
            if (newQuantity > 0) {
                item.quantity = newQuantity;
                renderCart();
                updateCartCountAndTotalBill();
            } else {
                deleteCartItem(itemId);
            }
        }
    }

    checkoutBtn.addEventListener("click", () => {
        alert("Proceeding to checkout!");
    });

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(loginForm);
        try {
            const response = await fetch('api/login.php', {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();

            if (data.success) {
                loginModal.style.display = "none";
                checkLoginStatus();
                fetchCartItems(); // Fetch cart items if user logs in
            } else {
                alert("Invalid username or password");
            }
        } catch (error) {
            console.error('Error logging in:', error);
            alert("Error logging in. Please try again.");
        }
    });

    logoutBtn.addEventListener("click", async () => {
        try {
            const response = await fetch('api/logout.php', {
                method: 'POST',
            });

            const data = await response.json();

            if (data.success) {
                checkLoginStatus();
                cartItems = []; // Clear cart items after logout
                renderCart(); // Render empty cart after logout
                updateCartCountAndTotalBill(); // Update cart count and total bill
            } else {
                alert("Failed to logout. Please try again.");
            }
        } catch (error) {
            console.error('Error logging out:', error);
            alert("Error logging out. Please try again.");
        }
    });

    function checkLoginStatus() {
        fetch('api/check_login.php')
            .then(response => response.json())
            .then(data => {
                if (data.logged_in) {
                    loginBtn.style.display = "none";
                    logoutBtn.style.display = "block";
                } else {
                    loginBtn.style.display = "block";
                    logoutBtn.style.display = "none";
                }
            })
            .catch(error => console.error('Error checking login status:', error));
    }

    function openLoginModal() {
        loginModal.style.display = "block";
    }

    function isLoggedIn() {
        return logoutBtn.style.display === "block";
    }

    window.onclick = function (event) {
        if (event.target == loginModal) {
            loginModal.style.display = "none";
        }
    };

    function fetchCartItems() {
        fetch('api/fetch_cart.php')
            .then(response => response.json())
            .then(data => {
                cartItems = data.cart_items;
                renderCart();
                updateCartCountAndTotalBill();
            })
            .catch(error => console.error('Error fetching cart items:', error));
    }

    fetchCartItems(); // Fetch initial cart items
});
