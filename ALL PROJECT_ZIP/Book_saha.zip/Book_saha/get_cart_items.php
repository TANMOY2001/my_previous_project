<?php
// update_cart_quantity.php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$item_id = $data['item_id'];
$quantity = $data['quantity'];

$stmt = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE user_id = ? AND item_id = ?");
$stmt->execute([$quantity, $user_id, $item_id]);

echo json_encode(['success' => true]);
?>
