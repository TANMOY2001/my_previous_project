<?php
// api/login.php

session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query to check if the username and password are correct
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
    $stmt->execute(['username' => $username, 'password' => $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (isset($_SESSION["logged_in"]) && $_SESSION["logged_in"]) {
            echo json_encode(["success" => false, "message" => "Another user is already logged in."]);
        } else {
            $_SESSION["logged_in"] = true;
            $_SESSION["username"] = $username;
            echo json_encode(["success" => true, "message" => "Login successful."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Invalid username or password"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method Not Allowed"]);
}
?>

