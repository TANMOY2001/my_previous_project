<?php
// Function to get the current URL
function getCurrentUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $currentUrl = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    return $currentUrl;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    // Check if inputs are valid
    if ($name && $email && $message) {
        // WhatsApp number (including country code, but without the + sign)
        $whatsappNumber = '919932488812'; // Replace with your actual WhatsApp number including country code (91 for India)

        // Get the current URL
        $currentUrl = getCurrentUrl();

        // Create the WhatsApp URL
        $text = urlencode("Name: $name\nEmail: $email\nMessage: $message\nPage URL: $currentUrl");
        $url = "https://api.whatsapp.com/send?phone=$whatsappNumber&text=$text";

        // Redirect to WhatsApp
        header("Location: $url");
        exit();
    } else {
        echo "Invalid input. Please go back and try again.";
    }
} else {
    echo "Invalid request method.";
}
?>

