<?php
session_start();
if(!isset($_SESSION['userdata'])){
    header("location: ../");
}

$userdata = $_SESSION['userdata'];
$groupdata = $_SESSION['groupdata'];

if($_SESSION['userdata']['status']==0){
    $status = '<b style="color:red">Not Voted</b>';
}
else{
    $status  = '<b style="color: green">Voted</b>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="stylesheet.css">
    <link rel="stylesheet" href="style_two.css">
</head>
<body>
    
    <div id="main">
        <center>
        <div id="header">
            <a href="index.html"><button id="backbtn">Back</button></a>
            <a href="logout.php"><button id="logoutbtn">Logout</button></a>
            <h1>Online Voting System</h1>
        </div>
    </center>
        <hr>
        <div id="pannel">
        <div id="profile">
            <center><img src="uploades/<?php echo $userdata['photo']?>" height="100" width="100"></center><br><br>
                <b>Name: </b> <?php echo $userdata['name']?> <br><br>
                <b>Mobile</b> <?php echo $userdata['mobile']?> <br><br>
                <b>Address</b> <?php echo $userdata['address']?><br><br>
                <b>Status:</b> <?php echo $status ?><br><br>
            </div>
        </div>
    <div class="gp"id="group">
        <?php
        if($_SESSION['groupdata']){
            for($i=0; $i<count($groupdata); $i++){
                ?>
                <div class="elementa">
                    <img style="float: right"src="uploades/<?php echo $groupdata[$i]['photo'] ?>" height="100" width="100">
                    <b>Group Name: </b><?php echo $groupdata[$i]['name'] ?> <br><br>
                    <b> Votes: </b><?php echo $groupdata[$i]['votes'] ?> <br><br>
                    <form action="vote.php" method="POST">
                        <input type="hidden" name="gvotes" value="<?php echo $groupdata[$i]['votes']?>">
                        <input type="hidden" name="gid" value="<?php echo $groupdata[$i]['id']?>">
                        <?php
                        if($_SESSION['userdata']['status']==0){
                            ?>
                            <input type="submit" name="votebtn" value="vote" id="votebtn">
                            <?php
                        }
                        else{
                            ?>
                            <button disabled type="button" name="votebtn" value="vote" id="voted">Voted</button>
                                <?php
                            }
                        ?>
                            
                    </form> 

                </div>
            </div>
            <hr>
            <?php
            }
        }
        else{

        }
        ?>
        </div>
    </div>
    <hr>
</body>
</html>