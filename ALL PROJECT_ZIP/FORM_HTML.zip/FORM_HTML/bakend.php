<?php
$SERVER="localhost";
$user="root";
$password="";

$con= mysqli_connect($SERVER, $user, $password);

if(!$con)
{
    die("<b>!!!db connection failed <b>".mysqli_connect_error());
}
else {
    echo "CONNECTION SUCESSFULL....,";    
}
$name = $_POST['name'];
$roll = $_POST['roll'];
$batch = $_POST['batch'];
$phone = $_POST['phone'];
$mail = $_POST['email'];
$birth = $_POST['birth'];
$gender = $_POST['gender'];

if(isset($_POST['btn']))
if(empty($name)) 
{
	echo"please Enter your Name";
}
// if(!preg_match("/^[a-zA-Z\s]+$/",$name))
// {
// 	echo "Please Enter Only String";
// }
// $sql = "INSERT INTO `std`.`info` (`name`, `roll`, `batch`, `phone`, `email`, `birth`, `gender`) VALUES ('$name', '$roll', '$batch', '$phone', '$mail', '$birth', '$gender' )";
$sql = INSERT INTO `info`(`id`, `name`, `roll`, `batch`, `phone`, `email`, `birth`, `gender`) VALUES ('[value-1]','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]')


if($con->query($sql)==true){
    echo "your data sucessfully inserted.....";
}
else{
    echo "!!!ERROR: $sql <br> $con->error";
}
$con->close();
?> 
