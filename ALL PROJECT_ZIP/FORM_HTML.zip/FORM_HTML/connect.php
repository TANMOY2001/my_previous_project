///<?php
//$server = "localhost";
//$username = "root";
//$password = "";
//$db_nme = "test";
//
//// Connection Sring
//$conn=mysqli_connect($server,$username,$password,$db_nme);
//if(!$conn){
//
//die('Connection Failed :'.conn->connection_error());
//
//if(isset($_POST['save'])){
//    $Email = $_POST['email'];
//    $password = $_POST['password'];
//    $stmt = $conn->prepare("insert into 'test','login'(email , password")values(?,?)
//
//}
//
//if(mysql_query($conn,$stmt)){
//    echo " Registration sucessfully...";
//}
//else{
//    echo " error " .$sql ."".mysqli_error($conn)
//}
//   
//    // $stmt->bind_param("ss"$Email,$password);
//    // $stmt->execute();
//    // $stmt->close();
//    // $conn.close();
////  $conn = new mysqli('localhost','root','','test');
//mysqli_close($conn)
//}
///?>

<?php
$SERVER="localhost";
$user="root";
$password="";

$con= mysqli_connect($SERVER, $user, $password);

if(!$con)
{
    die("<b>!!!db connection failed <b>".mysqli_connect_error());
}
else {
    echo "CONNECTION SUCESSFULL....,";    
}
$name = $_POST['name'];
$phone = $_POST['phone'];
$roll = $_POST['roll'];
$batch = $_POST['batch'];
$mail = $_POST['email'];
$birth = $_POST['birth'];
$gender = $_POST['gender'];

if(isset($_POST['btn']))
if(empty($name)) //
{
	echo"please Enter your Name";
}
if(!preg_match("/^[a-zA-Z\s]+$/",$name))
{
	echo "Please Enter Only String";
}
$sql = "INSERT INTO `std`.`info` (`name`, `roll`, `batch`, `phone`, `email`, `birth`, `gender`) VALUES ('$name', '$roll', '$batch', '$phone', '$mail', '$birth', '$gender' )";



if($con->query($sql)==true){
    echo "your data sucessfully inserted.....";
}
else{
    echo "!!!ERROR: $sql <br> $con->error";
}
$con->close();
?> 
