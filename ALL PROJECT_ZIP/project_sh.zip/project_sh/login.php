<?php
session_start();
include("connect.php");

$mobile = $_POST['mobile'];
$pasword = $_POST['password'];
$role = $_POST['role'];

$check = mysqli_query($connect,"SELECT * FROM reg WHERE mobile='$mobile' AND password='$pasword' AND role='$role' ");

if(mysqli_num_rows($check)>0){
    $userdata = mysqli_fetch_array($check);
    $group = mysqli_query($connect,"SELECT * FROM reg WHERE role=2");
    $groupdata = mysqli_fetch_all($group,MYSQLI_ASSOC);
    $_SESSION['userdata'] = $userdata;
    $_SESSION['groupdata'] = $groupdata;
    
    echo '
    <script>
        window.location = "dashboard.php";
    </script>
    ';
}
else{
    echo '
    <script>
        alert("Invalid Credential of Data Not Found!!");
        window.location = "../project_tg/index.html";
    </script>
    ';
}
?>