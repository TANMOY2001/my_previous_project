<?php
include("connect.php");

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$cpassword = $_POST['cpasswors'];
$address = $_POST['address'];
$image = $_FILES['photo']['name'];
$tmp_name = $_FILES['photo']['tmp_name'];
$folder = 'uploades/'.$image;
$role = $_POST['role'];

if($password == $cpassword){
    move_uploaded_file($tmp_name,$folder);
    // $insert = mysqli_query($connect,"INSERT INTO reg (name,mobile,address,password,photo,role,status,votes)VALUES ('$name','$mobile','$address','$password','$image','$role',0,0 )");

    $insert = mysqli_query($connect," INSERT INTO `reg`(`id`, `name`, `mobile`, `password`, `address`, `photo`, `role`, `status`, `votes`) VALUES ('[value-1]','$name','$mobile','$password','$address','$image','$role',0,0)");
    if($insert){
        echo '
        <script>
            alert("registration sucessfull");
            window.location = "../project_tg/index.html";
            </script>
        ';
        }
        else{
            echo '
            <script>
                alert("some error occured Your Registration is not complited !"
                window.location = "../register.html";
                </script>
            ';
        }
    }
    else{
        echo '
            <script>
                alert("Password and Confirm Password Should be Same!!");
                window.location = "register.html";
            </script>
    
        ';
    
    }

?>